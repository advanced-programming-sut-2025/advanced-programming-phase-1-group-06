package com.ap.Controller;

import com.ap.Model.Tile.Tile;

public class WorldController {
    Tile[][] tiles;
}
