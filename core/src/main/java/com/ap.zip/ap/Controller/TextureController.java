package com.ap.Controller;

import com.badlogic.gdx.graphics.g2d.TextureAtlas;

public class TextureController {
    private TextureAtlas plantAtlas;
    private TextureAtlas itemAtlas;
}
