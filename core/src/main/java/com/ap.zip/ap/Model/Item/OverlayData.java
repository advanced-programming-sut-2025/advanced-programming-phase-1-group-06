package com.ap.Model.Item;

import java.util.List;
import java.util.Map;

public class OverlayData {
    String id;
    List<Map<String, Object>> componentsData;
}
