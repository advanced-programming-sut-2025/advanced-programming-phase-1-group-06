package com.ap.Model.Item;

import com.ap.Model.Recipe;

class RecipeComponent extends Component { //for sold items that are recipes
    private Recipe recipe;
}
