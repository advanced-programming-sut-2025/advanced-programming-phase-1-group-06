package com.ap.Model.Item;

import com.ap.Model.Recipe;
import com.google.gson.*;
import java.io.FileReader;
import java.util.*;

public class Factory {
    private static Factory instance;

    HashMap<String, ItemData> items = new HashMap<>();
    HashMap<String, OverlayData> overlays;

    // Optional: from earlier steps
    HashMap<String, java.util.Map<String, Integer>> recipes;

    // Track which itemIds are artisan devices
    private final Set<String> artisanDeviceIds = new HashSet<>();

    // For each device itemId, store: HashMap<OUTPUT Item, ArrayList<INPUT Item>>
    private final Map<String, HashMap<Item, ArrayList<Item>>> deviceRecipeMaps = new HashMap<>();
    // Also remember processing hours for each OUTPUT (per device)Recipe
    private final Map<String, Map<String,Integer>> deviceProcessingHours = new HashMap<>();

    public static Factory getInstance() {
        if (instance == null) instance = new Factory();
        return instance;
    }

    public Factory() {
        try {
            Gson gson = new GsonBuilder().create();

            // Load base items via ItemDataRoot (existing behavior)
            FileReader reader = new FileReader("core/src/main/java/com/ap/Data/ItemData.json");
            ItemDataRoot root = gson.fromJson(reader, ItemDataRoot.class);
            if (root != null) {
                if (root.harvested_crops != null) for (ItemData d : root.harvested_crops) items.put(d.id, d);
                if (root.seeds != null)           for (ItemData d : root.seeds)           items.put(d.id, d);
                if (root.tools != null)           for (ItemData d : root.tools)           items.put(d.id, d);
                if (root.artisan_goods != null)   for (ItemData d : root.artisan_goods)   items.put(d.id, d);
                if (root.craftables != null)      for (ItemData d: root.craftables)       items.put(d.id, d);
            }

            // Parse devices & their recipe tables from the JSON (older Gson way)
            FileReader rawReader = new FileReader("core/src/main/java/com/ap/Data/ItemData.json");
            JsonElement parsedRoot = new JsonParser().parse(rawReader);
            JsonObject rawRoot = parsedRoot.getAsJsonObject();

            if (rawRoot.has("artisan_devices") && rawRoot.get("artisan_devices").isJsonArray()) {
                JsonArray devices = rawRoot.getAsJsonArray("artisan_devices");
                for (JsonElement el : devices) {
                    if (!el.isJsonObject()) continue;
                    JsonObject dev = el.getAsJsonObject();
                    String id   = optString(dev,"id");
                    String name = optString(dev,"name");
                    String desc = optString(dev,"description");
                    int stack   = optInt(dev,"stackSize",1);
                    String tex  = optString(dev,"texture");
                    int sell    = dev.has("sellPrice") && !dev.get("sellPrice").isJsonNull()
                        ? dev.get("sellPrice").getAsInt() : 0;

                    if (id != null && !id.isEmpty()) {
                        ItemData data = new ItemData();
                        data.id = id;
                        data.name = name;
                        data.description = desc;
                        data.stackSize = stack;
                        data.texture = tex;
                        data.basePrice = sell;
                        data.componentsData = new ArrayList<>();
                        items.put(id, data);
                        artisanDeviceIds.add(id);

                        HashMap<Item, ArrayList<Item>> outToInputs = new HashMap<>();
                        Map<String,Integer> outToHours = new HashMap<>();

                        if (dev.has("deviceRecipes") && dev.get("deviceRecipes").isJsonArray()) {
                            JsonArray arr = dev.getAsJsonArray("deviceRecipes");
                            for (JsonElement e : arr) {
                                if (!e.isJsonObject()) continue;
                                JsonObject r = e.getAsJsonObject();
                                String outputId = optString(r,"outputId");
                                int hours = optInt(r,"processingHours", 1);

                                Item outputItem = createItem(outputId);
                                if (outputItem == null) {
                                    outputItem = new Item(outputId, outputId, "Virtual output", 999);
                                }

                                ArrayList<Item> inputs = new ArrayList<>();
                                if (r.has("inputIds") && r.get("inputIds").isJsonArray()) {
                                    JsonArray inArr = r.getAsJsonArray("inputIds");
                                    for (JsonElement ie : inArr) {
                                        String inId = ie.getAsString();
                                        Item in;
                                        if (inId.startsWith("cat:")) {
                                            in = new Item(inId, inId, "Category placeholder", 999);
                                        } else {
                                            in = createItem(inId);
                                            if (in == null) in = new Item(inId, inId, "Virtual input", 999);
                                        }
                                        inputs.add(in);
                                    }
                                }

                                outToInputs.put(outputItem, inputs);
                                outToHours.put(outputItem.getId(), hours);
                            }
                        }

                        deviceRecipeMaps.put(id, outToInputs);
                        deviceProcessingHours.put(id, outToHours);
                    }
                }
            }
            Recipe.load();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ---------------------- Item creation ----------------------

    public Item createItem(String itemId) { return createItem(itemId, 1); }

    public Item createItem(String itemId, int amount) {
        ItemData data = items.get(itemId);
        if (data == null) return null;

        Item item = new Item(data.id, data.name, data.description, data.stackSize);
        if (data.getBasePrice() != 0) item.setPrice(data.getBasePrice());
        item.setAmount(amount);
        item.setTexturePath(data.texture);

        if (data.componentsData != null) {
            for (ComponentData component : data.componentsData) {
                if (component == null || component.type == null) continue;
                try {
                    Class<?> cls = Class.forName("com.ap.Model.Item." + component.type);
                    Object instance = cls.getDeclaredConstructor().newInstance();
                    if (instance instanceof Component) {
                        Component comp = (Component) instance;
                        java.lang.reflect.Field[] srcFields = ComponentData.class.getDeclaredFields();
                        for (java.lang.reflect.Field sf : srcFields) {
                            try {
                                java.lang.reflect.Field tf = cls.getDeclaredField(sf.getName());
                                tf.setAccessible(true);
                                sf.setAccessible(true);
                                Object val = sf.get(component);
                                if (val != null && !(val instanceof Number && ((Number) val).intValue() == 0)) {
                                    tf.set(comp, val);
                                }
                            } catch (NoSuchFieldException ignored) {}
                        }
                        comp.setObject(item);
                        item.addComponent(comp);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        if (artisanDeviceIds.contains(item.getId())) {
            ArtisanDeviceComponent deviceComp = new ArtisanDeviceComponent(item);
            HashMap<Item, ArrayList<Item>> map = deviceRecipeMaps.get(item.getId());
            if (map != null) deviceComp.setRecipes(map);
            Map<String,Integer> hours = deviceProcessingHours.get(item.getId());
            if (hours != null) deviceComp.setProcessingHours(hours);
            item.addComponent(deviceComp);
        }

        return item;
    }

    public Item cloneItem(Item item, int amount) {
        Item n = new Item(item.getId(), item.getName(), item.getDescription(), item.getStackSize());
        for (Component c : item.getComponents().values()) n.addComponent(c);
        n.setAmount(amount);
        return n;
    }

    public Item createItemByName(String name) {
        for (ItemData d : items.values()) if (d.id.equalsIgnoreCase(name)) return createItem(d.id);
        return null;
    }

    public Item createItemByName(String name, int amount) {
        for (ItemData d : items.values()) if (d.id.equalsIgnoreCase(name)) return createItem(d.id, amount);
        return null;
    }

    public boolean isArtisanDevice(String itemId) { return artisanDeviceIds.contains(itemId); }

    public HashMap<Item, ArrayList<Item>> getDeviceRecipes(String deviceItemId) {
        return deviceRecipeMaps.get(deviceItemId);
    }

    public Integer getProcessingHoursFor(String deviceItemId, String outputItemId) {
        Map<String,Integer> m = deviceProcessingHours.get(deviceItemId);
        return m == null ? null : m.get(outputItemId);
    }

    private static String optString(JsonObject obj, String key) {
        return obj.has(key) && !obj.get(key).isJsonNull() ? obj.get(key).getAsString() : null;
    }
    private static int optInt(JsonObject obj, String key, int fallback) {
        return obj.has(key) && !obj.get(key).isJsonNull() ? obj.get(key).getAsInt() : fallback;
    }
}
