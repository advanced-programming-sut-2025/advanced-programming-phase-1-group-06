package com.ap.Model.Tile;

import com.ap.Model.Item.Component;
import com.ap.Model.Item.FertilizerComponent;

public class DirtComponent extends Component {
    private boolean isHoed;
    private boolean isWatered;
    private FertilizerComponent fertilizer;
}
