package com.ap.Model.Item;

import java.util.ArrayList;

public class ItemDataRoot {
    public ArrayList<ItemData> harvested_crops;
    public ArrayList<ItemData> seeds;
    public ArrayList<ItemData> tools;
    public ArrayList<ItemData> artisan_goods;
    public ArrayList<ItemData> artisan_devices;
    public ArrayList<ItemData> craftables;
}
