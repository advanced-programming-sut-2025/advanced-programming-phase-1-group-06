package com.ap.Model.Item;

import com.ap.Main;
import com.ap.View.Clock;

import java.util.*;

/**
 * Holds a per-device recipe map: HashMap<OUTPUT Item, ArrayList<INPUT Item>>,
 * plus per-output processing hours. Supports start/cancel/update using the Clock.
 */
public class ArtisanDeviceComponent extends Component {

    public enum Status { IDLE, RUNNING, COMPLETE, CANCELED }

    private Item owner;

    // EXACT type you requested:
    private HashMap<Item, ArrayList<Item>> recipes = new HashMap<>();

    // Processing time per OUTPUT item id (in hours)
    private Map<String,Integer> processingHours = new HashMap<>();

    // Current job state
    private Status status = Status.IDLE;
    private List<Item> currentInputs;
    private Item currentOutput;
    private long endMinute;   // absolute minute on the game clock

    public ArtisanDeviceComponent() {}

    public ArtisanDeviceComponent(Item owner) {
        this.owner = owner;
        this.object = owner;
    }

    @Override
    public void setObject(Object object) {
        super.setObject(object);
        if (object instanceof Item) this.owner = (Item) object;
    }

    // ----------- wiring ------------

    public void setRecipes(HashMap<Item, ArrayList<Item>> recipes) {
        this.recipes = recipes != null ? recipes : new HashMap<>();
    }

    public HashMap<Item, ArrayList<Item>> getRecipes() {
        return recipes;
    }

    public void setProcessingHours(Map<String,Integer> processingHours) {
        this.processingHours = processingHours != null ? processingHours : new HashMap<>();
    }

    // ----------- crafting control ------------

    /**
     * Try to start crafting based on provided inputs.
     * We find the OUTPUT whose required inputs (by id & multiplicity) are satisfied.
     *
     * @param provided list of items supplied to the device (duplicates allowed to represent quantity)
     * @return true if a matching recipe is found and the process starts
     */
    public boolean startCrafting(List<Item> provided) {
        if (status == Status.RUNNING) return false;
        if (provided == null) return false;

        // Build a multiset(counts) of provided by id
        Map<String,Integer> providedCounts = toCounts(provided);

        // Find a matching recipe (OUTPUT -> required inputs)
        Item chosenOutput = null;
        ArrayList<Item> requiredInputs = null;
        for (Map.Entry<Item, ArrayList<Item>> e : recipes.entrySet()) {
            ArrayList<Item> req = e.getValue();
            if (req == null) continue;

            if (canSatisfy(providedCounts, req)) {
                chosenOutput = e.getKey();
                requiredInputs = req;
                break;
            }
        }

        if (chosenOutput == null) return false;

        // Determine processing hours
        int hours = 1;
        Integer h = processingHours.get(chosenOutput.getId());
        if (h != null) hours = h;

        Clock clock = Main.getInstance().getClock();
        if (clock == null) return false;

        long now = clock.getTotalMinutes();
        this.currentInputs = new ArrayList<>(requiredInputs);
        this.currentOutput = chosenOutput;
        this.endMinute = now + (long) hours * 60L;
        this.status = Status.RUNNING;
        return true;
    }

    public void cancel() {
        if (status == Status.RUNNING) status = Status.CANCELED;
        else status = Status.IDLE;
        currentInputs = null;
        currentOutput = null;
        endMinute = 0L;
    }

    public void update() {
        if (status != Status.RUNNING) return;
        Clock clock = Main.getInstance().getClock();
        if (clock == null) return;

        long now = clock.getTotalMinutes();
        if (now >= endMinute) {
            status = Status.COMPLETE;
            // Hand-off of currentOutput to inventory/ground etc. is up to the caller/UI layer
        }
    }

    public long getRemainingMinutes() {
        if (status != Status.RUNNING) return 0;
        Clock clock = Main.getInstance().getClock();
        if (clock == null) return 0;
        long now = clock.getTotalMinutes();
        return Math.max(0, endMinute - now);
    }

    public Status getStatus() { return status; }
    public Item getCurrentOutput() { return currentOutput; }
    public List<Item> getCurrentInputs() { return currentInputs; }

    // ----------- helpers ------------

    private static Map<String,Integer> toCounts(List<Item> items) {
        Map<String,Integer> m = new HashMap<>();
        for (Item it : items) {
            String id = it.getId();
            m.put(id, m.getOrDefault(id,0) + 1);
        }
        return m;
    }


    private static boolean canSatisfy(Map<String,Integer> providedCounts, ArrayList<Item> required) {
        // Work on a copy we can mutate
        Map<String,Integer> remaining = new HashMap<>(providedCounts);

        // First consume all concrete ids
        for (Item r : required) {
            String rid = r.getId();
            if (rid.startsWith("cat:")) continue; // handle categories later
            Integer have = remaining.get(rid);
            if (have == null || have <= 0) return false;
            if (have == 1) remaining.remove(rid); else remaining.put(rid, have - 1);
        }

        // Now satisfy category placeholders with any leftover item
        long neededCats = required.stream().filter(i -> i.getId().startsWith("cat:")).count();
        int totalLeft = remaining.values().stream().mapToInt(Integer::intValue).sum();
        return totalLeft >= neededCats;
    }
}
