package com.ap.Model.Overlay;

import com.ap.Model.Item.Component;

public class MineralComponent extends Component {
    //TODO will have health and returns item upon destruction
}
