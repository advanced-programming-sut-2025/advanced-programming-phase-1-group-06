package com.ap.Model;

public enum Season {
    SPRING, SUMMER, FALL, WINTER
}
