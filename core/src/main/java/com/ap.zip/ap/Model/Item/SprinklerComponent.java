package com.ap.Model.Item;

public class SprinklerComponent extends Component {
    private int wateringRadius;
    public SprinklerComponent(int wateringRadius) {
        this.wateringRadius = wateringRadius;
    }
}
