package com.ap.Model.Overlay;

public class TreeComponent {
    //TODO will have health and seasonal growth and returns item upon destruction
}
