package com.ap.Model;

public record Position(int x, int y) {}
