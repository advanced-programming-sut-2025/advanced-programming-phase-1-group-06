package com.ap.Model.Overlay;

import com.ap.Model.Item.Component;

public class ForagingCropComponent extends Component {
    private String harvestedCropId;
}
